import Sidebar from "@/components/Sidebar"; import { getSession } from "@/lib/auth"; import { redirect } from "next/navigation";
export default async function AppLayout({children}:{children:React.ReactNode}){ if(!await getSession()) redirect('/login'); return <div className="flex"><Sidebar/><main className="min-h-screen flex-1 p-4 lg:p-8">{children}</main></div> }
