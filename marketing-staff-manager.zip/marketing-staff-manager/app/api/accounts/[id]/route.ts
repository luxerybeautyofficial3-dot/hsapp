import { NextResponse } from "next/server"; import { requireUser } from "@/lib/auth"; import { supabaseAdmin } from "@/lib/supabase";
export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){ await requireUser('admin'); const {id}=await params; await supabaseAdmin.from('social_accounts').delete().eq('id',id); return NextResponse.redirect(new URL('/accounts',req.url)); }
