import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "إدارة موظفي التسويق", description: "Marketing staff management dashboard" };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="ar" dir="rtl"><body>{children}</body></html>; }
