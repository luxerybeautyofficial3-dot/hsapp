import Link from "next/link";
import { getSession } from "@/lib/auth";
import { BarChart3, Users, Share2, FileText, Settings, LayoutDashboard } from "lucide-react";
export default async function Sidebar(){
  const user = await getSession();
  const links = [
    ["/dashboard","لوحة التحكم",LayoutDashboard], ["/reports","التقارير",FileText],
    ...(user?.role === "admin" ? [["/employees","الموظفين",Users],["/accounts","الحسابات",Share2],["/settings","الإعدادات",Settings]] as any : [])
  ];
  return <aside className="min-h-screen w-72 bg-slate-950 p-5 text-white hidden lg:block">
    <div className="mb-8 rounded-3xl bg-white/10 p-4"><div className="text-xl font-black">إدارة التسويق</div><div className="text-sm text-slate-300">{user?.username} · {user?.role}</div></div>
    <nav className="space-y-2">{links.map(([href,label,Icon]:any)=><Link key={href} href={href} className="flex items-center gap-3 rounded-2xl px-4 py-3 hover:bg-white/10"><Icon size={20}/>{label}</Link>)}</nav>
    <form action="/api/auth/logout" method="post" className="mt-8"><button className="w-full rounded-2xl bg-rose-600 px-4 py-3 font-bold">تسجيل الخروج</button></form>
  </aside>
}
