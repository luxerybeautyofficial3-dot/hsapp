"use client";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
export default function ReportChart({data}:{data:any[]}){
 const grouped = Object.values(data.reduce((acc:any,r:any)=>{ const k=r.employee_name||"غير محدد"; acc[k] ||= {name:k, منشورات:0, رسائل:0, تصميمات:0, فيديوهات:0}; acc[k].منشورات += (+r.tiktok_morning_posts||0)+(+r.instagram_morning_posts||0)+(+r.scheduled_posts||0)+(+r.evening_posts||0); acc[k].رسائل += +r.sent_messages||0; acc[k].تصميمات += +r.designs_count||0; acc[k].فيديوهات += +r.videos_count||0; return acc; },{}));
 return <div className="card h-96"><h3 className="mb-4 text-lg font-black">أداء الموظفين اليوم</h3><ResponsiveContainer width="100%" height="85%"><BarChart data={grouped}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="name"/><YAxis/><Tooltip/><Bar dataKey="منشورات"/><Bar dataKey="رسائل"/><Bar dataKey="تصميمات"/><Bar dataKey="فيديوهات"/></BarChart></ResponsiveContainer></div>
}
