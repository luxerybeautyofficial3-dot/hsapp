import { ReactNode } from "react";
export default function StatCard({title,value,icon}:{title:string;value:string|number;icon?:ReactNode}){return <div className="card"><div className="flex items-center justify-between"><p className="text-sm text-slate-500">{title}</p><div className="text-indigo-600">{icon}</div></div><div className="mt-3 text-3xl font-black">{value}</div></div>}
