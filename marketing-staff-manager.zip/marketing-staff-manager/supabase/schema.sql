-- Marketing Staff Manager database schema
create extension if not exists "pgcrypto";

create table if not exists employees (
  id uuid primary key default gen_random_uuid(),
  employee_name text not null,
  username text not null unique,
  password_hash text,
  status text not null default 'active' check (status in ('active','inactive')),
  created_at timestamptz not null default now()
);

create table if not exists social_accounts (
  id uuid primary key default gen_random_uuid(),
  account_name text not null,
  platform text not null,
  employee_id uuid not null references employees(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists daily_reports (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references employees(id) on delete cascade,
  account_id uuid not null references social_accounts(id) on delete cascade,
  date date not null,
  tiktok_morning_posts integer not null default 0,
  instagram_morning_posts integer not null default 0,
  sent_messages integer not null default 0,
  designs_count integer not null default 0,
  videos_count integer not null default 0,
  scheduled_posts integer not null default 0,
  evening_posts integer not null default 0,
  created_at timestamptz not null default now()
);

-- لا نخزن كلمات المرور كنص عادي. الحقل password_hash يحتوي bcrypt hash فقط.
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique,
  password_hash text not null,
  role text not null check (role in ('admin','employee')),
  employee_id uuid references employees(id) on delete set null,
  auth_user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create or replace view daily_reports_view as
select r.*, e.employee_name, e.username as employee_username, a.account_name, a.platform
from daily_reports r
join employees e on e.id = r.employee_id
join social_accounts a on a.id = r.account_id;

alter table employees enable row level security;
alter table social_accounts enable row level security;
alter table daily_reports enable row level security;
alter table users enable row level security;

-- يستخدم التطبيق SERVICE_ROLE في السيرفر فقط، لذلك RLS محمي من المتصفح.
-- Admin seed: password is admin123, stored as bcrypt hash.
insert into users (username, password_hash, role)
values ('admin', crypt('admin123', gen_salt('bf', 12)), 'admin')
on conflict (username) do nothing;
