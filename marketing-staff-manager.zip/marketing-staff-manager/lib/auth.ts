import "server-only";
import { cookies } from "next/headers";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { supabaseAdmin } from "@/lib/supabase";

export type Role = "admin" | "employee";
export type SessionUser = { id: string; username: string; role: Role; employee_id?: string | null };
const cookieName = "sms_session";
const secret = process.env.APP_SESSION_SECRET || "dev-secret-change-me";

function sign(payload: string) {
  return crypto.createHmac("sha256", secret).update(payload).digest("base64url");
}
export function hashPassword(password: string) { return bcrypt.hash(password, 12); }
export function verifyPassword(password: string, hash: string) { return bcrypt.compare(password, hash); }
export async function createSession(user: SessionUser) {
  const payload = Buffer.from(JSON.stringify({ ...user, exp: Date.now() + 1000*60*60*24*7 })).toString("base64url");
  const token = `${payload}.${sign(payload)}`;
  (await cookies()).set(cookieName, token, { httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV === "production", path:"/", maxAge:60*60*24*7 });
}
export async function destroySession() { (await cookies()).delete(cookieName); }
export async function getSession(): Promise<SessionUser | null> {
  const token = (await cookies()).get(cookieName)?.value;
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig || sign(payload) !== sig) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (!data.exp || Date.now() > data.exp) return null;
    return { id:data.id, username:data.username, role:data.role, employee_id:data.employee_id };
  } catch { return null; }
}
export async function requireUser(role?: Role) {
  const user = await getSession();
  if (!user || (role && user.role !== role)) throw new Error("UNAUTHORIZED");
  return user;
}
export async function findUser(username: string) {
  const { data, error } = await supabaseAdmin.from("users").select("*").eq("username", username).single();
  if (error) return null;
  return data;
}
