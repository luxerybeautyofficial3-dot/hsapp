import "server-only";
import { supabaseAdmin } from "@/lib/supabase";
import { getSession } from "@/lib/auth";

export async function dashboardData() {
  const user = await getSession();
  const today = new Date().toISOString().slice(0,10);
  let q = supabaseAdmin.from("daily_reports_view").select("*").eq("date", today);
  if (user?.role === "employee" && user.employee_id) q = q.eq("employee_id", user.employee_id);
  const { data: rows = [] } = await q;
  const sum = (k:string) => rows.reduce((a:any,r:any)=>a+(Number(r[k])||0),0);
  const totalPosts = sum("tiktok_morning_posts") + sum("instagram_morning_posts") + sum("scheduled_posts") + sum("evening_posts");
  const byEmp:Record<string,number> = {}, byAcc:Record<string,number> = {};
  rows.forEach((r:any)=>{ const score=(+r.sent_messages||0)+(+r.designs_count||0)+(+r.videos_count||0)+(+r.tiktok_morning_posts||0)+(+r.instagram_morning_posts||0); byEmp[r.employee_name]=(byEmp[r.employee_name]||0)+score; byAcc[r.account_name]=(byAcc[r.account_name]||0)+score; });
  const topEmployee = Object.entries(byEmp).sort((a,b)=>b[1]-a[1])[0]?.[0] || "لا يوجد";
  const topAccount = Object.entries(byAcc).sort((a,b)=>b[1]-a[1])[0]?.[0] || "لا يوجد";
  return { rows, totalPosts, sentMessages:sum("sent_messages"), designs:sum("designs_count"), videos:sum("videos_count"), topEmployee, topAccount };
}
